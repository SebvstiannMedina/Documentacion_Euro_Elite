INSTRUCCIONES BÁSICA PARA EJECUTAR LA PÁGINA:

-Instalar python
-Instalar Django
-dirigirse a "cd Euro-Elite/euroelite"
python -m pip install Pillow
pip install requests
pip install pandas
pip install openpyxl
pip install psycopg2-binary
pip install resend
pip install google-cloud-bigquery google-cloud-storage google-auth
pip install -r requirements.txt



python manage.py runserver



carpeta de la página main es app

carpeta startproyect es euroelite

python manage.py createsuperuser

Usuario: Patricio
Email: mirandaservicespa@gmail.com
Contraseña: MirandaService

Usuario: Luis
Email: eutaquioalvaradol25@gmail.com
Contraseña: MirandaService2025



activar el entorno virtual:
.\venv\Scripts\Activate.ps1
